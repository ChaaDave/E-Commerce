package com.example.designuiux;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;


public class Profil_Activity extends AppCompatActivity {
    private String url = "https://chadave2022.000webhostapp.com/login.php";
    private String TAG = Profil_Activity.class.getSimpleName();
    private EditText Nama,Jenis,Tempat,Tanggal,Alamat,Email,Kontak;
    private Button Logout;
    private String user,pass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profil);


        Nama = findViewById(R.id.edNama);
        Jenis = findViewById(R.id.edJenis);
        Tempat = findViewById(R.id.edTempat);
        Tanggal = findViewById(R.id.edTanggal);
        Alamat = findViewById(R.id.edAlamat);
        Email = findViewById(R.id.edEmail);
        Kontak = findViewById(R.id.edKontak);
        Logout = findViewById(R.id.btnLogout);

        try{
            Bundle DataDariMain = getIntent().getExtras();
            user = URLEncoder.encode(DataDariMain.getString("user"), "utf-8");
            pass = URLEncoder.encode(DataDariMain.getString("pass"),"utf-8");

            new GetData().execute();

        }catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        Logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder DlgKeluar = new AlertDialog.Builder(Profil_Activity.this);
                // set pesan dari dialog
                DlgKeluar
                        .setMessage("Keluar dari aplikasi ?")
                        .setCancelable(false)
                        .setPositiveButton("Ya",new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog,int id) {
                                // jika tombol diklik, maka akan menutup activity ini
                                Profil_Activity.this.finish();
                            }
                        })
                        .setNegativeButton("Tidak",new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                // jika tombol ini diklik, akan menutup dialog
                                // dan tidak terjadi apa2
                                dialog.cancel();
                            }
                        });

                // membuat alert dialog dari builder
                AlertDialog Dialog = DlgKeluar.create();
                Dialog.show();
            }
        });
    }

    private class GetData extends AsyncTask<Void, Void, Void> {
        JSONObject Obj;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected Void doInBackground(Void... arg0) {
            HTTPHandler sh = new HTTPHandler();
            // Making a request to url and getting response
            String jsonStr = sh.makeServiceCall(url + "?username=" + user + "&password=" +pass);

            Log.e(TAG, "Response from url: " + jsonStr);
            if (jsonStr != null) {
                try {
                    Obj = new JSONObject(jsonStr);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                Nama.setText(Obj.getJSONObject("hasil").getString("nama"));
                                Jenis.setText(Obj.getJSONObject("hasil").getString("jenis_kelamin"));
                                Tempat.setText(Obj.getJSONObject("hasil").getString("tempat_lahir"));
                                Tanggal.setText(Obj.getJSONObject("hasil").getString("tanggal_lahir"));
                                Alamat.setText(Obj.getJSONObject("hasil").getString("alamat"));
                                Email.setText(Obj.getJSONObject("hasil").getString("email"));
                                Kontak.setText(Obj.getJSONObject("hasil").getString("kontak"));

                                Nama.setKeyListener(null);
                                Jenis.setKeyListener(null);
                                Tempat.setKeyListener(null);
                                Tanggal.setKeyListener(null);
                                Alamat.setKeyListener(null);
                                Email.setKeyListener(null);
                                Kontak.setKeyListener(null);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    });

                } catch (final JSONException e) {
                    Log.e(TAG, "Json parsing error: " + e.getMessage());
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(), "Json parsing error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    });

                }
            } else {
                Log.e(TAG, "Couldn't get json from server.");
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(getApplicationContext(), "Couldn't get json from server. Check LogCat for possible errors!", Toast.LENGTH_LONG).show();
                    }
                });
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
        }
    }
}