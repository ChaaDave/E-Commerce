package com.example.designuiux;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

public class LoginActivity extends AppCompatActivity {

    private String url = "https://chadave2022.000webhostapp.com/login.php";
    private String TAG = LoginActivity.class.getSimpleName();
    private EditText Username,Password;
    private Button Login;
    private String user,pass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Username = findViewById(R.id.TxtUsername);
        Password = findViewById(R.id.TxtPass);
        Login = findViewById(R.id.BtnLog);

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    user = URLEncoder.encode(Username.getText().toString(), "utf-8");
                    pass = URLEncoder.encode(Password.getText().toString(),"utf-8");

                    if (user.equals("") || pass.equals("")) {
                        Toast.makeText(LoginActivity.this, "Username/Password Tidak Boleh Kosong", Toast.LENGTH_LONG).show();
                    } else {
                        new GetData().execute();
                    }
                }catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
            }
        });
    }
    private class GetData extends AsyncTask<Void, Void, Void> {
        JSONObject Obj;
        String U,P;
        Intent keProfil;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected Void doInBackground(Void... arg0) {
            HTTPHandler sh = new HTTPHandler();
            // Making a request to url and getting response
            String jsonStr = sh.makeServiceCall(url + "?username=" + user + "&password=" +pass);

            Log.e(TAG, "Response from url: " + jsonStr);
            if (jsonStr != null) {
                try {
                    Obj = new JSONObject(jsonStr);

                    if(Obj.getJSONObject("hasil").length() == 0) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(getApplicationContext(), "Username atau password Salah", Toast.LENGTH_LONG).show();
                            }
                        });
                    }else {
                        U = Obj.getJSONObject("hasil").getString("username");
                        P = Obj.getJSONObject("hasil").getString("password");
                        keProfil = new Intent(LoginActivity.this, Profil_Activity.class);
                        keProfil.putExtra("user", U);
                        keProfil.putExtra("pass", P);
                        startActivity(keProfil);
                        finish();

                    }
                } catch (final JSONException e) {
                    Log.e(TAG, "Json parsing error: " + e.getMessage());
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(), "Json parsing error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    });

                }
            } else {
                Log.e(TAG, "Couldn't get json from server.");
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(getApplicationContext(), "Couldn't get json from server. Check LogCat for possible errors!", Toast.LENGTH_LONG).show();
                    }
                });
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
        }
    }
}
